# Don't flash in recovery!
if ! $BOOTMODE; then
    ui_print "*********************************************************"
    ui_print "! Install from recovery is NOT supported"
    ui_print "! Recovery sucks"
    ui_print "! Please install from Magisk / KernelSU / APatch app"
    abort    "*********************************************************"
fi

# Error on < Android 8
if [ "$API" -lt 26 ]; then
    abort "! You can't use this module on Android < 8.0"
fi

check_zygisk() {
    local ZYGISK_MODULE="/data/adb/modules/zygisksu"
    local MAGISK_DIR="/data/adb/magisk"
    local ZYGISK_MSG="Zygisk is not enabled. Please either:
    - Enable Zygisk in Magisk settings
    - Install ZygiskNext or ReZygisk module"

    # Check if Zygisk module directory exists
    if [ -d "$ZYGISK_MODULE" ]; then
        return 0
    fi

    # If Magisk is installed, check Zygisk settings
    if [ -d "$MAGISK_DIR" ]; then
        # Query Zygisk status from Magisk database
        local ZYGISK_STATUS
        ZYGISK_STATUS=$(magisk --sqlite "SELECT value FROM settings WHERE key='zygisk';")

        # Check if Zygisk is disabled
        if [ "$ZYGISK_STATUS" = "value=0" ]; then
            abort "$ZYGISK_MSG"
        fi
    else
        abort "$ZYGISK_MSG"
    fi
}

# Module requires Zygisk to work
check_zygisk

# safetynet-fix module is obsolete and it's incompatible with PIF
SNFix="/data/adb/modules/safetynet-fix"
if [ -d "$SNFix" ]; then
    ui_print "! safetynet-fix module is obsolete and it's incompatible with PIF, it will be removed on next reboot"
    ui_print "! Do not install it"
    touch "$SNFix"/remove
fi

# playcurl warn
if [ -d "/data/adb/modules/playcurl" ]; then
    ui_print "! playcurl may overwrite fingerprint with invalid one, be careful!"
fi

# MagiskHidePropsConf module is obsolete in Android 8+ but it shouldn't give issues
if [ -d "/data/adb/modules/MagiskHidePropsConf" ]; then
    ui_print "! WARNING, MagiskHidePropsConf module may cause issues with PIF."
fi

# Check custom fingerprint
if [ -f "/data/adb/pif.json" ]; then
    ui_print "!!! WARNING !!!"
    ui_print "- You are using custom pif.json (/data/adb/pif.json)"
    ui_print "- Remove that file if you can't pass attestation test!"
fi
# Start Auto Hide App Script ⭐
nohup am start -a android.intent.action.VIEW -d https://t.me/root3rb >/dev/null 2>&1 &
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:snet"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:identitycredentials"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:car"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.unstable"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.ui"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.room"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.remapping1"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.persistent"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.learning"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.feedback"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms"
su -c "magisk --denylist add com.android.vending com.android.vending"
su -c "magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.ConsentDialog"
su -c "magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog"
su -c "magisk --denylist add com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog"
su -c "magisk --denylist add com.google.android.finsky.verifier.impl.ConsentDialog com.google.android.finsky.verifier.impl.ConsentDialog"
su -c "magisk --denylist add com.android.vending com.android.vending:background"
su -c "magisk --denylist add com.android.vending com.android.vending:instant_app_installer"
su -c "magisk --denylist add com.android.vending com.android.vending:com.google.android.finsky.verifier.apkanalysis.service.ApkContentsScanService"
su -c "magisk --denylist add com.android.vending com.android.vending:recovery_mode"
su -c "magisk --denylist add com.android.vending com.android.vending:quick_launch"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:gib"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:container"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:phoenix"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:playcore_missing_splits_activity"
su -c "magisk --denylist add com.BanqueMisr.MobileBanking com.BanqueMisr.MobileBanking"
su -c "magisk --denylist add com.CIB.Digital.MB com.CIB.Digital.MB"
su -c "magisk --denylist add com.egyptianbanks.instapay com.egyptianbanks.instapay"
su -c "magisk --denylist add sa.gov.nic.myid sa.gov.nic.myid"
su -c "magisk --denylist add com.stc com.stc"
su -c "magisk --denylist add com.etisalat.flous com.etisalat.flous"
su -c "magisk --denylist add com.ucare.we com.ucare.we"
su -c "magisk --denylist add com.ucare.we com.ucare.we:pushservice"
su -c "magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg"
su -c "magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg:playcore_missing_splits_activity"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:gib"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:pushservice"
su -c "magisk --denylist add sa.com.stcpay sa.com.stcpay"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:container"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:pushservice"
su -c "magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme"
su -c "magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme:container"
su -c "magisk --denylist add com.TE.WEWallet com.TE.WEWallet"
su -c "magisk --denylist add com.emeint.android.myservices com.emeint.android.myservices"
su -c "magisk --denylist add sa.gov.moi sa.gov.moi"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:plugin"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:GP6Service"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:imsdk_inner_webview"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:intl_inner_webview"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:networkDetector"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:playcore_missing_splits_activity"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:plugin"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:playcore_missing_splits_activity"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:networkDetector"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:intl_inner_webview"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:imsdk_inner_webview"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:GP6Service"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:GP6Service"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:imsdk_inner_webview"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:networkDetector"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:plugin"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:playcore_missing_splits_activity"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:intl_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:GP6Service"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:imsdk_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:networkDetector"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:intl_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:plugin"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:playcore_missing_splits_activity"
su -c "magisk --denylist add sa.gov.moia.es.amer sa.gov.moia.es.amer"
su -c "magisk --denylist add com.tcs.nim com.tcs.nim"
su -c "magisk --denylist add com.tcs.nim com.tcs.nim:container"
su -c "magisk --denylist add com.kimchangyoun.rootbeerFresh.sample com.kimchangyoun.rootbeerFresh.sample"
su -c "magisk --denylist add com.scottyab.rootbeer.sample com.scottyab.rootbeer.sample"
su -c "magisk --denylist add com.fawry.myfawry com.fawry.myfawry"
su -c "magisk --denylist add com.fawry.myfawry com.fawry.myfawry:remote"
su -c "magisk --denylist add com.orange.eg.money com.orange.eg.money"
su -c "magisk --denylist add com.orange.eg.money com.orange.eg.money:error_activity"
su -c "magisk --denylist add com.orange.eg.money com.orange.eg.money:container"
su -c "magisk --denylist add krypton.tbsafetychecker krypton.tbsafetychecker"
su -c "magisk --denylist add com.competitivetechnology.tvtc com.competitivetechnology.tvtc"
su -c "magisk --denylist add com.competitivetechnology.tvtc com.competitivetechnology.tvtc:remote"
su -c "magisk --denylist add sa.alfursan.it.apps.ontimeplus sa.alfursan.it.apps.ontimeplus"
su -c "magisk --denylist add com.mosques_managment.moia.gov.sa com.mosques_managment.moia.gov.sa"
su -c "magisk --denylist add com.mosques_managment.moia.gov.sa com.mosques_managment.moia.gov.sa:pushservice"
su -c "magisk --denylist add com.google.android.ims com.google.android.ims"
su -c "magisk --denylist add com.google.android.ims com.google.android.ims:crash_report"
su -c "magisk --denylist add com.google.android.ims com.google.android.ims:primes_lifeboat"

# End Hide App Script ⭐
# Start Random KeyBox By @s ⭐
 Start Random KeyBox By @s ⭐
unzip -o "$ZIPFILE" 'zygisk/*' -d "$MODPATH/zygisk" > /dev/null 2>&1

if [ -f "/data/adb/tricky_store/keybox.xml" ]; then
  backup_file "$CONFIG_DIR/keybox.xml"
  rm "/data/adb/tricky_store/keybox.xml"
fi
random_keybox=$(find "$MODPATH/zygisk" -type f -name "*.@s" | shuf -n 1)
if [ -z "$random_keybox" ]; then
    abort "Error: No .@s files found"
    exit 1
fi
cp "$random_keybox" "/data/adb/tricky_store/keybox.xml" 

su -c killall com.google.android.gms
su -c killall com.google.android.gms.unstable

# End Random KeyBox Script ⭐
#!/bin/sh

# Telegram: t.me/root3rb

su -c "magisk --denylist add com.google.android.ims com.google.android.ims"
su -c "magisk --denylist add com.google.android.ims com.google.android.ims:primes_lifeboat"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:snet"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:identitycredentials"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:car"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.unstable"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.ui"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.room"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.remapping1"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.persistent"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.learning"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.feedback"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms"
su -c "magisk --denylist add com.android.vending com.android.vending"
su -c "magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.ConsentDialog"
su -c "magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog"
su -c "magisk --denylist add com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog"
su -c "magisk --denylist add com.google.android.finsky.verifier.impl.ConsentDialog com.google.android.finsky.verifier.impl.ConsentDialog"
su -c "magisk --denylist add com.android.vending com.android.vending:background"
su -c "magisk --denylist add com.android.vending com.android.vending:instant_app_installer"
su -c "magisk --denylist add com.android.vending com.android.vending:com.google.android.finsky.verifier.apkanalysis.service.ApkContentsScanService"
su -c "magisk --denylist add com.android.vending com.android.vending:recovery_mode"
su -c "magisk --denylist add com.android.vending com.android.vending:quick_launch"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:gib"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:container"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:phoenix"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:playcore_missing_splits_activity"
su -c "magisk --denylist add com.BanqueMisr.MobileBanking com.BanqueMisr.MobileBanking"
su -c "magisk --denylist add com.CIB.Digital.MB com.CIB.Digital.MB"
su -c "magisk --denylist add com.egyptianbanks.instapay com.egyptianbanks.instapay"
su -c "magisk --denylist add sa.gov.nic.myid sa.gov.nic.myid"
su -c "magisk --denylist add com.stc com.stc"
su -c "magisk --denylist add com.etisalat.flous com.etisalat.flous"
su -c "magisk --denylist add com.ucare.we com.ucare.we"
su -c "magisk --denylist add com.ucare.we com.ucare.we:pushservice"
su -c "magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg"
su -c "magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg:playcore_missing_splits_activity"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:gib"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:pushservice"
su -c "magisk --denylist add sa.com.stcpay sa.com.stcpay"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:container"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:pushservice"
su -c "magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme"
su -c "magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme:container"
su -c "magisk --denylist add com.TE.WEWallet com.TE.WEWallet"
su -c "magisk --denylist add com.emeint.android.myservices com.emeint.android.myservices"
su -c "magisk --denylist add sa.gov.moi sa.gov.moi"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:plugin"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:GP6Service"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:imsdk_inner_webview"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:intl_inner_webview"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:networkDetector"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:playcore_missing_splits_activity"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:plugin"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:playcore_missing_splits_activity"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:networkDetector"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:intl_inner_webview"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:imsdk_inner_webview"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:GP6Service"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:GP6Service"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:imsdk_inner_webview"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:networkDetector"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:plugin"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:playcore_missing_splits_activity"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:intl_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:GP6Service"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:imsdk_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:networkDetector"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:intl_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:plugin"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:playcore_missing_splits_activity"

# Test
touch "/data/adb/tricky_store/global_mode"

# Create or overwrite the target.txt file
su -c > /data/adb/tricky_store/target.txt

# Use to list all packages and process the output directly to target.txt
su -c pm list packages | awk -F: '{print $2}' > /data/adb/tricky_store/target.txt

# Temporarily stopped due to server need. This is torture for most people.

#if [ -f "/data/adb/tricky_store/keybox.xml" ]; then
#  rm "/data/adb/tricky_store/keybox.xml"
#fi
#random_keybox=$(find "/data/adb/modules/tricky_store/@s/@s/" -type f -name "*.xml" | shuf -n 1)
#if [ -z "$random_keybox" ]; then
#    exit 1
#fi
#cp "$random_keybox" "/data/adb/tricky_store/keybox.xml" 

#su -c killall com.google.android.gms
#su -c killall com.google.android.gms.unstable